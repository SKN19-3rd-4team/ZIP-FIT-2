
  # HTML CSS JS Bootstrap Implementation

  This is a code bundle for HTML CSS JS Bootstrap Implementation. The original project is available at https://www.figma.com/design/e4xm4vyo6RdntTgois3sqR/HTML-CSS-JS-Bootstrap-Implementation.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  